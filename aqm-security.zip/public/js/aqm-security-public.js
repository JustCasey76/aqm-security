/**
 * Public JavaScript for AQM Security
 */
(function($) {
    'use strict';

    // This file is intentionally left mostly empty as most of the functionality is handled server-side
    // We may add client-side functionality in the future if needed

})(jQuery);
